// Enhanced popup and popunder triggers for maximum revenue
(function() {
    'use strict';
    
    let popupTriggered = false;
    let popunderTriggered = false;
    
    // Multiple trigger strategies for maximum coverage
    function triggerPopup() {
        if (popupTriggered) return;
        popupTriggered = true;
        
        // Try multiple popup methods
        try {
            // Method 1: Direct window.open
            if (typeof window.open !== 'undefined') {
                setTimeout(() => {
                    const popup = window.open('https://violationtones.com/wk3jtk9r7?key=f1a89e3aaa7086cc2113978186f98dcd', '_blank', 'width=1,height=1,scrollbars=no');
                    if (popup) {
                        setTimeout(() => popup.close(), 1000);
                    }
                }, 100);
            }
        } catch (e) {
            console.log('Popup blocked');
        }
    }
    
    function triggerPopunder() {
        if (popunderTriggered) return;
        popunderTriggered = true;
        
        try {
            // Create popunder
            const popunder = window.open('https://violationtones.com/wk3jtk9r7?key=f1a89e3aaa7086cc2113978186f98dcd', '_blank');
            if (popunder) {
                popunder.blur();
                window.focus();
            }
        } catch (e) {
            console.log('Popunder blocked');
        }
    }
    
    // Trigger on user interactions
    const events = ['click', 'touchstart', 'mousedown', 'keydown'];
    events.forEach(event => {
        document.addEventListener(event, function() {
            if (!popupTriggered) {
                triggerPopup();
            }
            if (!popunderTriggered) {
                setTimeout(triggerPopunder, 500);
            }
        }, { once: true, passive: true });
    });
    
    // Backup timer-based triggers
    setTimeout(() => {
        if (!popupTriggered) {
            triggerPopup();
        }
    }, 5000);
    
    setTimeout(() => {
        if (!popunderTriggered) {
            triggerPopunder();
        }
    }, 8000);
    
    // Export for external use
    window.forcePopup = triggerPopup;
    window.forcePopunder = triggerPopunder;
})();